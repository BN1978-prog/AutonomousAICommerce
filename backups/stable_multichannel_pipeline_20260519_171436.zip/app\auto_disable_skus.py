import json
from pathlib import Path

IMPORTS = Path("app/logs/imported_skus.json")
BLOCKED = Path("app/logs/blocked_products.json")

imports = json.loads(IMPORTS.read_text(encoding="utf-8"))

if BLOCKED.exists():
    blocked = json.loads(BLOCKED.read_text(encoding="utf-8"))
else:
    blocked=[]

new_blocked=[]

for sku, data in imports.items():

    score = data.get("last_score", None)
    stock = data.get("current_inventory",10)
    status = data.get("status","")

    reasons=[]

    if score is not None and score < 60:
        reasons.append("low_score")

    if stock <=0:
        reasons.append("out_of_stock")

    if reasons:
        new_blocked.append({
            "sku":sku,
            "reasons":reasons
        })

BLOCKED.write_text(
    json.dumps(new_blocked,indent=2),
    encoding="utf-8"
)

print("BLOCKED:",len(new_blocked))
